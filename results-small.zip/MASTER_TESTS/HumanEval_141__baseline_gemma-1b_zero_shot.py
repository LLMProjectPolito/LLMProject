import re

def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9]{3,}\.([a-zA-Z]{2})$", file_name):
        return 'No'
    else:
        parts = file_name.split('.')
        if len(parts) != 2:
            return 'No'
        if not parts[0]:
            return 'No'
        if not parts[1]:
            return 'No'
        if not parts[1].startswith('a') and not parts[1].startswith('A'):
            return 'No'
        if parts[1] in ['txt', 'exe', 'dll']:
            return 'Yes'
        else:
            return 'No'