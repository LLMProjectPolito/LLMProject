import pytest
import math

def test_basic():
    assert solve("#a@C") == "#A@c"

def test_no_letters():
    assert solve("1234") == "4321"

import pytest

def solve(s):
    """You are given a string s.
    if s[i] is a letter, reverse its case from lower to upper or vise versa, 
    otherwise keep it as it is.
    If the string contains no letters, reverse the string.
    The function should return the resulted string.
    Examples
    solve("1234") = "4321"
    solve("ab") = "AB"
    solve("#a@C") = "#A@c"
    """
    has_letter = False
    result = ""
    for char in s:
        if 'a' <= char <= 'z' or 'A' <= char <= 'Z':
            has_letter = True
            if 'a' <= char <= 'z':
                result += char.upper()
            else:
                result += char.lower()
        else:
            result += char
    if not has_letter:
        return result[::-1]
    return result

def test_solve_empty_string():
    assert solve("") == ""