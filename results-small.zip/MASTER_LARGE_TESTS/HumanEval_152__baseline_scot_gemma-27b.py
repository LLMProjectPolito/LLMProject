# STEP 1: REASONING
# The function `compare` takes two lists, `game` and `guess`, of equal length.
# It calculates the absolute difference between corresponding elements in the two lists.
# If the elements are equal, the difference is 0.
# The function returns a new list containing these differences.
# We need to test cases with:
# - Correct guesses
# - Incorrect guesses
# - Mixed correct and incorrect guesses
# - Empty lists
# - Lists with negative numbers
# - Lists with zero values

# STEP 2: PLAN
# 1. test_correct_guesses: Test with all guesses correct.
# 2. test_incorrect_guesses: Test with all guesses incorrect.
# 3. test_mixed_guesses: Test with a mix of correct and incorrect guesses.
# 4. test_empty_lists: Test with empty lists.
# 5. test_negative_numbers: Test with lists containing negative numbers.
# 6. test_zero_values: Test with lists containing zero values.
# 7. test_different_lengths: Test with lists of different lengths (should raise ValueError).

# STEP 3: CODE
import pytest

def compare(game,guess):
    """I think we all remember that feeling when the result of some long-awaited
    event is finally known. The feelings and thoughts you have at that moment are
    definitely worth noting down and comparing.
    Your task is to determine if a person correctly guessed the results of a number of matches.
    You are given two arrays of scores and guesses of equal length, where each index shows a match. 
    Return an array of the same length denoting how far off each guess was. If they have guessed correctly,
    the value is 0, and if not, the value is the absolute difference between the guess and the score.
    
    
    example:

    compare([1,2,3,4,5,1],[1,2,3,4,2,-2]) -> [0,0,0,0,3,3]
    compare([0,5,0,0,0,4],[4,1,1,0,0,-2]) -> [4,4,1,0,0,6]
    """
    if len(game) != len(guess):
        raise ValueError("Lists must be of equal length")
    result = []
    for i in range(len(game)):
        if game[i] == guess[i]:
            result.append(0)
        else:
            result.append(abs(game[i] - guess[i]))
    return result

def test_correct_guesses():
    assert compare([1, 2, 3, 4, 5], [1, 2, 3, 4, 5]) == [0, 0, 0, 0, 0]

def test_incorrect_guesses():
    assert compare([1, 2, 3, 4, 5], [6, 7, 8, 9, 10]) == [5, 5, 5, 5, 5]

def test_mixed_guesses():
    assert compare([1, 2, 3, 4, 5], [1, 2, 0, 4, 2]) == [0, 0, 3, 0, 3]

def test_empty_lists():
    assert compare([], []) == []

def test_negative_numbers():
    assert compare([-1, -2, -3], [-1, 0, -3]) == [0, 2, 0]

def test_zero_values():
    assert compare([0, 0, 0], [0, 1, 0]) == [0, 1, 0]

def test_different_lengths():
    with pytest.raises(ValueError):
        compare([1, 2, 3], [1, 2])