import pytest
from your_module import generate_integers  # Replace your_module

class TestGenerateIntegers:
    """
    Comprehensive pytest suite for the generate_integers function.
    """

    def test_basic_ascending(self):
        """Test basic ascending order case."""
        assert generate_integers(2, 8) == [2, 4, 6, 8]

    def test_basic_descending(self):
        """Test basic descending order case."""
        assert generate_integers(8, 2) == [2, 4, 6, 8]

    def test_no_even_numbers(self):
        """Test case where there are no even numbers in the range."""
        assert generate_integers(10, 14) == []

    def test_single_even_number(self):
        """Test case with a single even number in the range."""
        assert generate_integers(2, 3) == [2]

    def test_start_and_end_are_even(self):
        """Test case where both start and end are even."""
        assert generate_integers(4, 8) == [4, 6, 8]

    def test_start_is_odd_end_is_even(self):
        """Test case where start is odd and end is even."""
        assert generate_integers(1, 6) == [2, 4, 6]

    def test_start_is_even_end_is_odd(self):
        """Test case where start is even and end is odd."""
        assert generate_integers(6, 7) == [6]

    def test_same_number(self):
        """Test case where start and end are the same."""
        assert generate_integers(4, 4) == []

    def test_large_range(self):
        """Test with a larger range to check performance and correctness."""
        assert generate_integers(100, 120) == [100, 102, 104, 106, 108, 110, 112, 114, 116, 118, 120]

    def test_edge_case_zero(self):
        """Test edge case where a or b is zero (should not happen based on problem description, but good to check)."""
        with pytest.raises(TypeError):  # Expect TypeError as a and b must be positive
            generate_integers(0, 5)

    def test_edge_case_negative(self):
        """Test edge case where a or b is negative (should not happen based on problem description)."""
        with pytest.raises(TypeError):  # Expect TypeError as a and b must be positive
            generate_integers(-2, 5)

    def test_invalid_input_type(self):
        """Test with invalid input types (e.g., strings, floats)."""
        with pytest.raises(TypeError):
            generate_integers("2", 8)
        with pytest.raises(TypeError):
            generate_integers(2, 8.5)

    def test_empty_range(self):
        """Test when a > b, but both are even."""
        assert generate_integers(8, 4) == [4, 6, 8]

    @pytest.mark.parametrize(
        "a, b, expected",
        [
            (2, 8, [2, 4, 6, 8]),
            (8, 2, [2, 4, 6, 8]),
            (10, 14, []),
            (2, 3, [2]),
            (4, 8, [4, 6, 8]),
            (1, 6, [2, 4, 6]),
            (6, 7, [6]),
            (4, 4, []),
            (100, 120, [100, 102, 104, 106, 108, 110, 112, 114, 116, 118, 120]),
        ],
    )
    def test_parameterized(self, a, b, expected):
        """Test using pytest.mark.parametrize for multiple test cases."""
        assert generate_integers(a, b) == expected

    def test_a_is_negative(self):
        """Test with a negative input (should raise ValueError)."""
        with pytest.raises(TypeError):
            generate_integers(-2, 8)

    def test_b_is_negative(self):
        """Test with b negative input (should raise ValueError)."""
        with pytest.raises(TypeError):
            generate_integers(2, -8)

    def test_a_and_b_negative(self):
        """Test with both a and b negative (should raise ValueError)."""
        with pytest.raises(TypeError):
            generate_integers(-2, -8)

    def test_a_is_zero(self):
        """Test when a is zero (should raise ValueError)."""
        with pytest.raises(TypeError):
            generate_integers(0, 8)

    def test_b_is_zero(self):
        """Test when b is zero (should raise ValueError)."""
        with pytest.raises(TypeError):
            generate_integers(2, 0)

    def test_a_and_b_zero(self):
        """Test when both a and b are zero (should raise ValueError)."""
        with pytest.raises(TypeError):
            generate_integers(0, 0)

    def test_large_numbers(self):
        """Test with large numbers to ensure efficiency."""
        assert generate_integers(1000, 2000) == [1000, 1002, 1004, 1006, 1008, 1010, 1012, 1014, 1016, 1018, 1020, 1022, 1024, 1026, 1028, 1030, 1032, 1034, 1036, 1038, 1040, 1042, 1044, 1046, 1048, 1050, 1052, 1054, 1056, 1058, 1060, 1062, 1064, 1066, 1068, 1070, 1072, 1074, 1076, 1078, 1080, 1082, 1084, 1086, 1088, 1090, 1092, 1094, 1096, 1098, 1100, 1102, 1104, 1106, 1108, 1110, 1112, 1114, 1116, 1118, 1120, 1122, 1124, 1126, 1128, 1130, 1132, 1134, 1136, 1138, 1140, 1142, 1144, 1146, 1148, 1150, 1152, 1154, 1156, 1158, 1160, 1162, 1164, 1166, 1168, 1170, 1172, 1174, 1176, 1178, 1180, 1182, 1184, 1186, 1188, 1190, 1192, 1194, 1196, 1198, 1200, 1202, 1204, 1206, 1208, 1210, 1212, 1214, 1216, 1218, 1220, 1222, 1224, 1226, 1228, 1230, 1232, 1234, 1236, 1238, 1240, 1242, 1244, 1246, 1248, 1250, 1252, 1254, 1256, 1258, 1260, 1262, 1264, 1266, 1268, 1270, 1272, 1274, 1276, 1278, 1280, 1282, 1284, 1286, 1288, 1290, 1292, 1294, 1296, 1298, 1300, 1302, 1304, 1306, 1308, 1310, 1312, 1314, 1316, 1318, 1320, 1322, 1324, 1326, 1328, 1330, 1332, 1334, 1336, 1338, 1340, 1342, 1344, 1346, 1348, 1350, 1352, 1354, 1356, 1358, 1360, 1362, 1364, 1366, 1368, 1370, 1372, 1374, 1376, 1378, 1380, 1382, 1384, 1386, 1388, 1390, 1392, 1394, 1396, 1398, 1400, 1402, 1404, 1406, 1408, 1410, 1412, 1414, 1416, 1418, 1420, 1422, 1424, 1426, 1428, 1430, 1432, 1434, 1436, 1438, 1440, 1442, 1444, 1446, 1448, 1450, 1452, 1454, 1456, 1458, 1460, 1462, 1464, 1466, 1468, 1470, 1472, 1474, 1476, 1478, 1480, 1482, 1484, 1486, 1488, 1490, 1492, 1494, 1496, 1498, 1500, 1502, 1504, 1506, 1508, 1510, 1512, 1514, 1516, 1518, 1520, 1522, 1524, 1526, 1528, 1530, 1532, 1534, 1536, 1538, 1540, 1542, 1544, 1546, 1548, 1550, 1552, 1554, 1556, 1558, 1560, 1562, 1564, 1566, 1568, 1570, 1572, 1574, 1576, 1578, 1580, 1582, 1584, 1586, 1588, 1590, 1592, 1594, 1596, 1598, 1600, 1602, 1604, 1606, 1608, 1610, 1612, 1614, 1616, 1618, 1620, 1622, 1624, 1626, 1628, 1630, 1632, 1634, 1636, 1638, 1640, 1642, 1644, 1646, 1648, 1650, 1652, 1654, 1656, 1658, 1660, 1662, 1664, 1666, 1668, 1670, 1672, 1674, 1676, 1678, 1680, 1682, 1684, 1686, 1688, 1690, 1692, 1694, 1696, 1698, 1700, 1702, 1704, 1706, 1708, 1710, 1712, 1714, 1716, 1718, 1720, 1722, 1724, 1726, 1728, 1730, 1732, 1734, 1736, 1738, 1740, 1742, 1744, 1746, 1748, 1750, 1752, 1754, 1756, 1758, 1760, 1762, 1764, 1766, 1768, 1770, 1772, 1774, 1776, 1778, 1780, 1782, 1784, 1786, 1788, 1790, 1792, 1794, 1796, 1798, 1800]